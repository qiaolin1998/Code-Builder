$ErrorActionPreference='Stop'
$dir='e:\华为家庭存储\Project\Obsidian\Code Builder\Studio 5000\Tot_V15'
$l5x=Join-Path $dir 'TempAlarm16_L2_AOI.L5X'
$stp=Join-Path $dir 'TempAlarm16_L2.st'
$st=Get-Content -LiteralPath $stp -Encoding UTF8

$L=New-Object System.Collections.Generic.List[string]
function A([string]$s){ $L.Add($s) | Out-Null }

A '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
A '<RSLogix5000Content SchemaRevision="1.0" SoftwareRevision="36.00" TargetName="TempAlarm16_L2" TargetType="AddOnInstructionDefinition" TargetRevision="1.2 " TargetLastEdited="2026-10-22T00:00:00.000Z" ContainsContext="true" ExportDate="Thu Oct 22 00:00:00 2026" ExportOptions="References NoRawData L5KData DecoratedData Context Dependencies ForceProtectedEncoding AllProjDocTrans">'
A '<Controller Use="Context" Name="TempAlarm16_L2">'
A '<DataTypes Use="Context">'
A '<DataType Name="TempAlarm16_L2_Type" Family="NoFamily" Class="User">'
A '<Members>'

function MBit([string]$name,[int]$bit,[string]$desc){
  A ('<Member Name="'+$name+'" DataType="BIT" Dimension="0" Radix="Decimal" Hidden="false" Target="ZZZZZZZZZZTempAlarm16_L20" BitNumber="'+$bit+'" ExternalAccess="Read/Write">')
  A '<Description>'; A ('<![CDATA['+$desc+']]>'); A '</Description>'; A '</Member>'
}
function MArr([string]$name,[string]$dt,[int]$dim,[string]$radix,[string]$desc){
  A ('<Member Name="'+$name+'" DataType="'+$dt+'" Dimension="'+$dim+'" Radix="'+$radix+'" Hidden="false" ExternalAccess="Read/Write">')
  A '<Description>'; A ('<![CDATA['+$desc+']]>'); A '</Description>'; A '</Member>'
}

A '<Member Name="ZZZZZZZZZZTempAlarm16_L20" DataType="SINT" Dimension="0" Radix="Decimal" Hidden="true" ExternalAccess="Read/Write"/>'
MBit 'Apply_Batch' 0 '批量参数写入命令(点动置位, 处理完自动复位)'
MBit 'Reset_Log'   1 '清空事件记录命令(点动置位, 处理完自动复位)'
MBit 'Ack_Alm2'    2 '二级报警确认命令(弹窗确认按钮, 清除全部未确认锁存)'
MArr 'PV'         'REAL' 16 'Float'   '16路实时温度(由模拟量换算程序写入)'
MArr 'Cfg_Name'   'STRING' 16 'NullType' '测点标识名(事件记录快照源, HMI可修改)'
MArr 'Cfg_Enable' 'BOOL' 16 'Decimal' '各通道使能(1=投入 0=退出)'
MArr 'Cfg_SP1'    'REAL' 16 'Float'   '一级报警阈值(提示/高报)'
MArr 'Cfg_SP2'    'REAL' 16 'Float'   '二级报警阈值(警告/高报)'
MArr 'Cfg_Hys'    'REAL' 16 'Float'   '回差值(解除阈值=SP-Hys)'
MArr 'Cfg_Dly1'   'DINT' 16 'Decimal' '一级报警防抖延时(秒)'
MArr 'Cfg_Dly2'   'DINT' 16 'Decimal' '二级报警防抖延时(秒)'
MArr 'Sta_Alm1'   'BOOL' 16 'Decimal' '一级报警状态(1=报警中, 非强制提示)'
MArr 'Sta_Alm2'   'BOOL' 16 'Decimal' '二级报警状态(1=报警中, 强制介入)'
MArr 'Alm2_UnAck' 'BOOL' 16 'Decimal' '二级报警未确认锁存(确认前保持, 驱动弹窗/声响)'
MArr 'Any_Alm1'   'BOOL' 0  'Decimal' '任一路一级报警总标志(横幅提示)'
MArr 'Any_Alm2'   'BOOL' 0  'Decimal' '任一路二级报警总标志'
MArr 'Any_Alm2_UnAck' 'BOOL' 0 'Decimal' '任一二级报警未确认总标志(弹窗+声响)'
MArr 'Alm1_Count' 'DINT' 0  'Decimal' '当前一级报警通道数'
MArr 'Alm2_Count' 'DINT' 0  'Decimal' '当前二级报警通道数'
MArr 'User_Level' 'DINT' 0  'Decimal' '当前操作员权限等级(>=2允许修改参数)'
MArr 'B_Group'    'DINT' 0  'Decimal' '批量目标组(0=全部 1=定子 2=电机轴承 3=泵轴承 4=减速机油)'
MArr 'B_SP1'      'REAL' 0  'Float'   '批量下发: 一级阈值'
MArr 'B_SP2'      'REAL' 0  'Float'   '批量下发: 二级阈值'
MArr 'B_Hys'      'REAL' 0  'Float'   '批量下发: 回差值'
MArr 'B_Dly1'     'DINT' 0  'Decimal' '批量下发: 一级延时(秒)'
MArr 'B_Dly2'     'DINT' 0  'Decimal' '批量下发: 二级延时(秒)'
MArr 'B_EnableOpt' 'DINT' 0 'Decimal' '批量使能选项(0=不修改 1=全部启用 2=全部禁用)'
MArr 'Evt_Head'   'DINT' 0  'Decimal' '事件环形缓冲写指针(0..31)'
MArr 'Evt_Ch'     'DINT' 32 'Decimal' '事件通道号(参数事件记录组号)'
MArr 'Evt_ChName' 'STRING' 32 'NullType' '事件测点标识名快照(精准定位测点)'
MArr 'Evt_Type'   'DINT' 32 'Decimal' '事件类型(1=一级产生 2=一级解除 3=二级产生 4=二级解除 5=参数修改 6=越权拒绝)'
MArr 'Evt_PV'     'REAL' 32 'Float'   '事件发生时的温度值'
MArr 'Evt_H'      'DINT' 32 'Decimal' '事件时标-时'
MArr 'Evt_M'      'DINT' 32 'Decimal' '事件时标-分'
MArr 'Evt_S'      'DINT' 32 'Decimal' '事件时标-秒'

A '</Members>'
A '</DataType>'
A '</DataTypes>'
A '<AddOnInstructionDefinitions Use="Context">'
A '<AddOnInstructionDefinition Use="Target" Name="TempAlarm16_L2" Revision="1.2" ExecutePrescan="false" ExecutePostscan="false" ExecuteEnableInFalse="false" CreatedDate="2026-10-20T00:00:00.000Z" CreatedBy="Trae" EditedDate="2026-10-22T00:00:00.000Z" EditedBy="Trae" SoftwareRevision="v36.00">'
A '<Parameters>'

function PBool([string]$name,[string]$usage,[string]$desc){
  A ('<Parameter Name="'+$name+'" TagType="Base" DataType="BOOL" Usage="'+$usage+'" Radix="Decimal" Required="false" Visible="false" ExternalAccess="Read Only">')
  A '<Description>'; A ('<![CDATA['+$desc+']]>'); A '</Description>'
  A '<DefaultData Format="L5K">'; A '<![CDATA[0]]>'; A '</DefaultData>'
  A '<DefaultData Format="Decorated">'; A '<DataValue DataType="BOOL" Radix="Decimal" Value="0"/>'; A '</DefaultData>'
  A '</Parameter>'
}
function PDint([string]$name,[string]$desc){
  A ('<Parameter Name="'+$name+'" TagType="Base" DataType="DINT" Usage="Input" Radix="Decimal" Required="false" Visible="false" ExternalAccess="Read/Write">')
  A '<Description>'; A ('<![CDATA['+$desc+']]>'); A '</Description>'
  A '<DefaultData Format="L5K">'; A '<![CDATA[0]]>'; A '</DefaultData>'
  A '<DefaultData Format="Decorated">'; A '<DataValue DataType="DINT" Radix="Decimal" Value="0"/>'; A '</DefaultData>'
  A '</Parameter>'
}

PBool 'EnableIn'  'Input'  '使能输入'
PBool 'EnableOut' 'Output' '使能输出'
PDint 'Hour'   '系统时钟-时(事件记录时标)'
PDint 'Minute' '系统时钟-分(事件记录时标)'
PDint 'Second' '系统时钟-秒(事件记录时标, 同时作为防抖秒节拍)'
PBool 'Out_Warn' 'Output' '一级报警总出口(非强制提示横幅, 任一路一级报警时置位)'
PBool 'Out_Trip' 'Output' '二级报警总出口(停机联锁, 任一路二级报警时置位)'
PBool 'Out_Horn' 'Output' '声响提醒输出(任一二级报警未确认时置位, 确认后复位)'
A '<Parameter Name="HMI_CMD" TagType="Base" DataType="TempAlarm16_L2_Type" Usage="InOut" Required="true" Visible="true" Constant="false">'
A '<Description>'; A '<![CDATA[HMI批量配置/状态/未确认锁存/事件记录(掉电保持)]]>'; A '</Description>'
A '</Parameter>'
A '</Parameters>'
A '<LocalTags>'

function LDintArr([string]$name,[int]$dim,[string]$desc){
  A ('<LocalTag Name="'+$name+'" DataType="DINT" Dimension="'+$dim+'" Radix="Decimal" ExternalAccess="None">')
  A '<Description>'; A ('<![CDATA['+$desc+']]>'); A '</Description>'
  A '<DefaultData Format="L5K">'; A '<![CDATA[0]]>'; A '</DefaultData>'
  A '<DefaultData Format="Decorated">'; A '<DataValue DataType="DINT" Radix="Decimal" Value="0"/>'; A '</DefaultData>'
  A '</LocalTag>'
}
function LBoolArr([string]$name,[int]$dim,[string]$desc){
  A ('<LocalTag Name="'+$name+'" DataType="BOOL" Dimension="'+$dim+'" Radix="Decimal" ExternalAccess="None">')
  A '<Description>'; A ('<![CDATA['+$desc+']]>'); A '</Description>'
  A '<DefaultData Format="L5K">'; A '<![CDATA[[0,0]]]>'; A '</DefaultData>'
  A '<DefaultData Format="Decorated">'; A '<DataValue DataType="BOOL" Radix="Decimal" Value="0"/>'; A '</DefaultData>'
  A '</LocalTag>'
}
function LDint([string]$name,[string]$desc){
  A ('<LocalTag Name="'+$name+'" DataType="DINT" Radix="Decimal" ExternalAccess="None">')
  A '<Description>'; A ('<![CDATA['+$desc+']]>'); A '</Description>'
  A '<DefaultData Format="L5K">'; A '<![CDATA[0]]>'; A '</DefaultData>'
  A '<DefaultData Format="Decorated">'; A '<DataValue DataType="DINT" Radix="Decimal" Value="0"/>'; A '</DefaultData>'
  A '</LocalTag>'
}
function LBool([string]$name,[string]$desc){
  A ('<LocalTag Name="'+$name+'" DataType="BOOL" Radix="Decimal" ExternalAccess="None">')
  A '<Description>'; A ('<![CDATA['+$desc+']]>'); A '</Description>'
  A '<DefaultData Format="L5K">'; A '<![CDATA[0]]>'; A '</DefaultData>'
  A '<DefaultData Format="Decorated">'; A '<DataValue DataType="BOOL" Radix="Decimal" Value="0"/>'; A '</DefaultData>'
  A '</LocalTag>'
}

# 注意: AOI 本地变量仅允许原子数据类型, 不能使用 TIMER
LDintArr 'Acc1' 16 '各通道一级报警防抖秒计数'
LDintArr 'Acc2' 16 '各通道二级报警防抖秒计数'
LBoolArr 'PrevAlm1' 16 '一级报警状态边沿检测(上一周期值)'
LBoolArr 'PrevAlm2' 16 '二级报警状态边沿检测(上一周期值)'
LBool 'Tick' '秒节拍(Second 变化时为1)'
LDint 'Prev_Second' '上一扫描周期的秒值'
LDint 'i'  'FOR循环索引'
LDint 'GS' '批量写入起始通道下标'
LDint 'GE' '批量写入结束通道下标'
LBool 'IsFirstScan' '首次扫描标志(上电写入默认整定值与测点名)'
A '</LocalTags>'
A '<Routines>'
A '<Routine Name="Logic" Type="ST">'
A '<STContent>'
for($k=0;$k -lt $st.Count;$k++){
  A ('<Line Number="'+$k+'">')
  A ('<![CDATA['+$st[$k]+']]>')
  A '</Line>'
}
A '</STContent>'
A '</Routine>'
A '</Routines>'
A '<Dependencies>'
A '<Dependency Type="DataType" Name="TempAlarm16_L2_Type"/>'
A '</Dependencies>'
A '</AddOnInstructionDefinition>'
A '</AddOnInstructionDefinitions>'
A '</Controller>'
A '</RSLogix5000Content>'

$outTxt=($L -join "`n")+"`n"
[System.IO.File]::WriteAllText($l5x,$outTxt,(New-Object System.Text.UTF8Encoding($false)))
$x=New-Object System.Xml.XmlDocument; $x.Load($l5x)
$bad=@($x.SelectNodes('//LocalTags/LocalTag') | Where-Object { $_.DataType -eq 'TIMER' })
Write-Output ("OK lines=$($L.Count) bytes=$([System.IO.File]::ReadAllBytes($l5x).Length) Params=$($x.SelectNodes('//Parameters/Parameter').Count) Members=$($x.SelectNodes('//DataType/Members/Member').Count) LocalTags=$($x.SelectNodes('//LocalTags/LocalTag').Count) STLines=$($x.SelectNodes('//STContent/Line').Count) TimerTags=$($bad.Count)")
